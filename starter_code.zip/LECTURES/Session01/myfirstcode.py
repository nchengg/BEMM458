print("hello world")
print("hello code")



