# Session folder

Use this folder to make notes, replicate the code examples in the session lecture.