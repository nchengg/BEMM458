# Session workspace

You can  this folder to save your work files on the session activities.